function Pe = ppm_binario(SNRdB,MonteCarlo)

SNR = 10.^(SNRdB/10);
N0 = 1;
E = SNR*N0;

for i=1:length(SNR)
    Enow = E(i);
    for z=1:MonteCarlo
        bitTx = randi([0,1],1);
        if(bitTx == 1)
            sym = [sqrt(E),0];
        else
            sym = [0,sqrt(E)];
        end
        
    end
    
end