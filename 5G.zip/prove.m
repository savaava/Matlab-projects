vett = zeros(1, 10);
for i=1:10
    vett(i) = i/10;
    vett(i)
    pause;
end