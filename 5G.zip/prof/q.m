function y=q(x)

y=.5*(1-erf(x/sqrt(2)));

