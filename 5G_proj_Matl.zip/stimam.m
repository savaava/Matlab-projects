function y=stimam(n)
x=randn(1,n);
y=mean(x);